package com.sunil.moneyTransfer.dto;

import java.io.Serializable;

public class BaseModel implements Serializable {

}
