package com.sunil.Credit.Credit.config;

public class KafkaTopicConfig {

}
