package com.sunil.registary;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RegistaryApplicationTests {

	@Test
	void contextLoads() {
	}

}
