package com.sunil.forexcomponent;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ForexcomponentApplicationTests {

	@Test
	void contextLoads() {
	}

}
