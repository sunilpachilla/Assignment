package com.sunil.forexcomponent.dto;

import java.io.Serializable;

public class BaseModel implements Serializable{

}
