package com.sunil.forexcomponent.service;

import com.sunil.forexcomponent.dto.ForexRequest;
import com.sunil.forexcomponent.dto.ForexResponse;

public interface ForexManager {
	
public ForexResponse getRates(ForexRequest req);

}
